<?php
    class Note extends Model {
        public
            $id,
            $userId,
            $content,
            $dateCreation,
            $commentCount;
    }
?>