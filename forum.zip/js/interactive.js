jQuery(document).ready(function(){
    $('#redactor_content').redactor();
    $('.comments').tooltip({
        placement: 'bottom'
    });
});