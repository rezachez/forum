jQuery(function(){
    $('#redactor_content').redactor({
        imageUpload: './upload.php',
        imageGetJson: false
    });
});